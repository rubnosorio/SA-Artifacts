#!/usr/bin/python 
#import de distutils que permitira crear el artefacto
from distutils.core import setup 
# DATOS RELEVANTES DEL PROYECTO A SER CONSTRUIDO
setup (name = 'Servicio Repartidor', 
          description = "Servicio de entrega de ordenes de restaurante", 
          author = "Ruben Osorio", 
          author_email = "rubenosorio88@gmail.com", 
          version = '1.1.1' 
          )
